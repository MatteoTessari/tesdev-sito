# Tesdev — testi pronti / ready-to-use texts

Usali liberamente per parlare di Tesdev e dei suoi giochi.
Feel free to use these texts to write about Tesdev and its games.

## Tesdev (IT)
**Breve:** Tesdev è un piccolo studio italiano che fa giochi per telefono.
**Lungo:** Tesdev è un piccolo studio indipendente italiano. Fa giochi per telefono da tenere in tasca e riprendere dopo cena. Ogni mondo nasce in 3D e poi viene ridipinto a mano, finché la luce sembra vera. Il primo gioco è Lamplight Town.

## Tesdev (EN)
**Short:** Tesdev is a small Italian studio making phone games.
**Long:** Tesdev is a small independent studio from Italy. It makes phone games you can keep in your pocket and pick up again after dinner. Every world starts in 3D and is then repainted by hand, until the light feels real. Its first game is Lamplight Town.

## Lamplight Town (IT)
**Una riga:** Riaccendi un paese al tramonto, un livello alla volta.
**Breve:** Una sera il paese di Lamplight Town si spegne e nessuno sa perché. Sei il nuovo sindaco: vinci livelli rompicapo e riaccendi i negozi uno alla volta, dal forno di Rosa al bar.
**Lungo:** Una sera il paese di Lamplight Town si spegne e nessuno sa perché. Al tramonto le vetrine restano buie e gli abitanti aspettano qualcuno che riporti la luce. Sei il nuovo sindaco. Scambi i pezzi, ne allinei tre o più, crei pezzi speciali: ogni livello vinto riaccende un negozio. Gli abitanti, un pezzo alla volta, ti raccontano cosa è successo, e ogni capitolo della storia ti lascia una figurina nell'album dei ricordi. Partite brevi, un paese sempre al tramonto.

## Lamplight Town (EN)
**One line:** Relight a sunset town, one puzzle at a time.
**Short:** One evening the town of Lamplight Town goes dark and nobody knows why. You're the new mayor: win puzzle levels and relight the shops one by one, from Rosa's bakery to the café.
**Long:** One evening the town of Lamplight Town goes dark and nobody knows why. At sunset the shop windows stay black and the townsfolk wait for someone to bring the light back. You're the new mayor. Swap pieces, match three or more, build special pieces: every level you win relights a shop. Bit by bit, the townsfolk tell you what happened, and each chapter of the story leaves a card in the memory album. Short sessions, in a town that's always at sunset.

## Scheda / Factsheet
- Sviluppatore / Developer: Tesdev (Italia / Italy)
- Gioco / Game: Lamplight Town
- Genere / Genre: rompicapo con storia / story-driven puzzle
- Piattaforma / Platform: Android (Google Play)
- Uscita / Release: da annunciare / to be announced
- Prezzo / Price: gratis / free
- Lingue / Languages: italiano, English
- Contatti / Contact: tesdev.studio@gmail.com
- Social: @tesdev_studio (TikTok, Instagram)
